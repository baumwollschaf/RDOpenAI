# RDOpenAI
Delphi implementation of ChatGPT - an event based component.

All you need is an own API key from here: https://platform.openai.com/account/api-keys

Copyright © 2023 Ralph Dietrich.
