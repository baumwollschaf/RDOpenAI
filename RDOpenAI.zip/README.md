# RDOpenAI
Delphi implementation of ChatGPT - an event based component.

Copyright © 2023 Ralph Dietrich.
